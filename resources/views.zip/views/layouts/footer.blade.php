 <footer class="footer">
    <div class="d-sm-flex justify-content-end">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">{{__('copyright')}} © <?= date('Y') ?> <a class="text-theme" href="{{ url('/') }}">{{config('app.name')}}</a>. {{__('all_rights_reserved')}}.</span>
     </div>
</footer>
